class NotSupportType(Exception):
    """
    Raised the problem given isn't supported.
    """
    pass

class GetItemError(Exception):
    pass